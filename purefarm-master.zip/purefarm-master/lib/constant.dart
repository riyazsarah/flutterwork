class Config {
  static const String apiBaseUrl = 'app.purefarm.in:8002';
  static const String sendOtpApiEndpoint = '/otp/send';
  static const String tokenApiEndpoint = '/oauth/token';
  static const String smsKey = 'opt#Fr3sca';
  static const String smsUser = 'belal';
  static const String smsPassword = 'belal@123';
  
}